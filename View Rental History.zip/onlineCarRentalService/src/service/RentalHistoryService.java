package service;

import model.User;
import repository.UserRepository;

public class RentalHistoryService {
    private UserRepository userRepository = new UserRepository();

    public User authenticateUser(String email, String password) {
        return userRepository.getUserByEmailAndPassword(email, password);
    }
}