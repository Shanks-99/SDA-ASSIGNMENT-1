package ui;

import model.RentalRecord;
import model.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RentalHistoryUI {

    public void displayRentalHistory(User user) {
        JFrame frame = new JFrame("Car Rental Service - Rental History");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout()); // Use BorderLayout to place the button at the bottom

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBackground(new Color(230, 240, 255));

        JLabel header = new JLabel("Rental History for " + user.getEmail(), JLabel.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 16));
        header.setForeground(new Color(0, 102, 204));

        mainPanel.add(header);
        mainPanel.add(new JSeparator());

        for (RentalRecord record : user.getRentalHistory()) {
            JLabel recordLabel = new JLabel(record.toString());
            recordLabel.setFont(new Font("Arial", Font.PLAIN, 14));
            mainPanel.add(recordLabel);
        }

        // Panel for the sign-out button
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(230, 240, 255));  // Match background color
        JButton signOutButton = new JButton("Sign Out");
        signOutButton.setBackground(new Color(204, 0, 0));
        signOutButton.setForeground(Color.WHITE);
        signOutButton.setFont(new Font("Arial", Font.BOLD, 14));
        signOutButton.setPreferredSize(new Dimension(100, 30));

        // Sign-out action
        signOutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();  // Close the rental history frame
                SwingUtilities.invokeLater(() -> new LoginUI().displayLogin());  // Show the login page again
            }
        });

        buttonPanel.add(signOutButton);

        // Add main panel to the center and button panel to the bottom
        frame.add(mainPanel, BorderLayout.CENTER);
        frame.add(buttonPanel, BorderLayout.SOUTH);

        frame.setLocationRelativeTo(null);  // Center the frame
        frame.setVisible(true);
    }
}
