package ui;

import model.User;
import service.RentalHistoryService;

import javax.swing.*;
import java.awt.*;

public class LoginUI {
    private RentalHistoryService rentalHistoryService = new RentalHistoryService();

    public void displayLogin() {
        // Create the main frame
        JFrame frame = new JFrame("Car Rental Service - Login");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Set an eye-catching background color for the main panel
        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(new Color(230, 240, 255));
        mainPanel.setLayout(new BorderLayout());

        // Create a centered panel for the form
        JPanel formPanel = new JPanel();
        formPanel.setLayout(new GridBagLayout());
        formPanel.setOpaque(false);  // Make formPanel inherit the background color from mainPanel

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);  // Add padding around components

        // Create the components
        JLabel title = new JLabel("  Car Rental History", JLabel.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 18));
        title.setForeground(new Color(0, 102, 204));

        JLabel emailLabel = new JLabel("Email:");
        JTextField emailField = new JTextField(20);
        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField(20);
        JButton loginButton = new JButton("Login");

        // Style the login button with a custom color and font
        loginButton.setBackground(new Color(0, 153, 76));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFont(new Font("Arial", Font.BOLD, 16));
        loginButton.setPreferredSize(new Dimension(80, 30));  // Set a fixed size

        // Position components using GridBagLayout
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(0, 50, 100, 0);  // Space between title and email field
        formPanel.add(title, gbc);

        gbc.gridwidth = 1;  // Reset grid width for individual components
        gbc.gridy = 1;
        gbc.insets = new Insets(10, 10, 10, 10);  // Reset insets
        gbc.gridx = 0;
        formPanel.add(emailLabel, gbc);

        gbc.gridx = 1;
        formPanel.add(emailField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(passwordLabel, gbc);

        gbc.gridx = 1;
        formPanel.add(passwordField, gbc);

        // Add extra space between password field and login button
        gbc.insets = new Insets(50, 80, 10, 80);  // Space between password field and login button
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.CENTER;
        formPanel.add(loginButton, gbc);

        // Add form panel to the main panel
        mainPanel.add(formPanel, BorderLayout.CENTER);

        // Add main panel to the frame
        frame.add(mainPanel);

        // Handle login action
        loginButton.addActionListener(e -> {
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());

            // Debugging the input values
            System.out.println("Attempting to login with email: " + email);

            // Call the authenticate method and log the result
            User user = rentalHistoryService.authenticateUser(email, password);
            if (user != null) {
                System.out.println("Login successful for user: " + email);
                frame.dispose(); // Close the login frame

                // Display the rental history UI
                SwingUtilities.invokeLater(() -> {
                    try {
                        new RentalHistoryUI().displayRentalHistory(user);
                    } catch (Exception ex) {
                        ex.printStackTrace(); // Log any exceptions
                        JOptionPane.showMessageDialog(frame, "An error occurred while opening the user profile.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                });
            } else {
                System.out.println("Login failed: Invalid email or password.");
                JOptionPane.showMessageDialog(frame, "Invalid email or password.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Center the window and make it visible
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}