package model;

import java.time.LocalDate;

public class RentalRecord {
    private Car car;
    private LocalDate startDate;
    private LocalDate endDate;

    // Constructor
    public RentalRecord(Car car, LocalDate startDate, LocalDate endDate) {
        this.car = car;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    // Getter methods
    public Car getCar() {
        return car;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    @Override
    public String toString() {
        return car + " | From: " + startDate + " to: " + endDate;
    }
}

