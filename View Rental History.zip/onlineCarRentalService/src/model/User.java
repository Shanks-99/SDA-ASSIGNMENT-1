package model;

import java.util.List;

public class User {
    private String email;
    private String password;
    private List<RentalRecord> rentalHistory;

    public User(String email, String password, List<RentalRecord> rentalHistory) {
        this.email = email;
        this.password = password;
        this.rentalHistory = rentalHistory;
    }

    public String getEmail() { return email; }
    public String getPassword() { return password; }
    public List<RentalRecord> getRentalHistory() { return rentalHistory; }
}