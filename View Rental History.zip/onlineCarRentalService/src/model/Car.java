package model;

public class Car {
    private String make;
    private String model;
    private String registrationNumber;

    public Car(String make, String model, String registrationNumber) {
        this.make = make;
        this.model = model;
        this.registrationNumber = registrationNumber;
    }

    @Override
    public String toString() {
        return make + " " + model + " (" + registrationNumber + ")";
    }
}