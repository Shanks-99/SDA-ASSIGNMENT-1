package repository;

import model.Car;
import model.RentalRecord;
import model.User;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class UserRepository {
    private List<User> users = new ArrayList<>();

    public UserRepository() {
        seedUsers();
    }

    public User getUserByEmailAndPassword(String email, String password) {
        return users.stream()
                .filter(user -> user.getEmail().equals(email) && user.getPassword().equals(password))
                .findFirst().orElse(null);
    }

    private void seedUsers() {
        // Predefined cars for rental histories
        Car car1 = new Car("Toyota", "Camry", "ABC123");
        Car car2 = new Car("Honda", "Civic", "XYZ789");
        Car car3 = new Car("Ford", "Focus", "DEF456");
        Car car4 = new Car("Chevrolet", "Malibu", "GHI012");
        Car car5 = new Car("Nissan", "Altima", "JKL345");

        // Adding 5 users with 4 to 6 rental records each

        users.add(new User("hadi454@gmail.com", "hadi765", List.of(
                new RentalRecord(car1, LocalDate.of(2023, 1, 10), LocalDate.of(2023, 1, 15)),
                new RentalRecord(car2, LocalDate.of(2023, 2, 5), LocalDate.of(2023, 2, 10)),
                new RentalRecord(car3, LocalDate.of(2023, 3, 1), LocalDate.of(2023, 3, 7)),
                new RentalRecord(car4, LocalDate.of(2023, 4, 15), LocalDate.of(2023, 4, 20))
        )));

        users.add(new User("john.doe@gmail.com", "john1234", List.of(
                new RentalRecord(car1, LocalDate.of(2023, 5, 5), LocalDate.of(2023, 5, 10)),
                new RentalRecord(car4, LocalDate.of(2023, 6, 15), LocalDate.of(2023, 6, 20)),
                new RentalRecord(car5, LocalDate.of(2023, 7, 1), LocalDate.of(2023, 7, 6)),
                new RentalRecord(car2, LocalDate.of(2023, 8, 10), LocalDate.of(2023, 8, 15))
        )));

        users.add(new User("mary.smith@yahoo.com", "mary5678", List.of(
                new RentalRecord(car2, LocalDate.of(2023, 2, 1), LocalDate.of(2023, 2, 6)),
                new RentalRecord(car3, LocalDate.of(2023, 3, 10), LocalDate.of(2023, 3, 15)),
                new RentalRecord(car1, LocalDate.of(2023, 4, 5), LocalDate.of(2023, 4, 10)),
                new RentalRecord(car4, LocalDate.of(2023, 5, 20), LocalDate.of(2023, 5, 25)),
                new RentalRecord(car5, LocalDate.of(2023, 6, 10), LocalDate.of(2023, 6, 15))
        )));

        users.add(new User("james.brown@outlook.com", "james2345", List.of(
                new RentalRecord(car3, LocalDate.of(2023, 7, 3), LocalDate.of(2023, 7, 8)),
                new RentalRecord(car1, LocalDate.of(2023, 8, 5), LocalDate.of(2023, 8, 10)),
                new RentalRecord(car2, LocalDate.of(2023, 9, 15), LocalDate.of(2023, 9, 20)),
                new RentalRecord(car5, LocalDate.of(2023, 10, 1), LocalDate.of(2023, 10, 6)),
                new RentalRecord(car4, LocalDate.of(2023, 11, 10), LocalDate.of(2023, 11, 15))
        )));

        users.add(new User("emily.jameson@gmail.com", "emily7890", List.of(
                new RentalRecord(car5, LocalDate.of(2023, 1, 15), LocalDate.of(2023, 1, 20)),
                new RentalRecord(car3, LocalDate.of(2023, 2, 10), LocalDate.of(2023, 2, 15)),
                new RentalRecord(car2, LocalDate.of(2023, 3, 1), LocalDate.of(2023, 3, 5)),
                new RentalRecord(car1, LocalDate.of(2023, 4, 20), LocalDate.of(2023, 4, 25)),
                new RentalRecord(car4, LocalDate.of(2023, 5, 5), LocalDate.of(2023, 5, 10))
        )));
    }
}